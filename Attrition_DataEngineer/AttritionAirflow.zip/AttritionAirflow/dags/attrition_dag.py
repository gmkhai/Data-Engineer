from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python_operator import PythonOperator
from AttritionData import AttritionClass
with DAG(
    'AttritionProject1',
    default_args={
        'depends_on_past': False,
        'email': ['airflow@example.com'],
        'email_on_failure': False,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
    description='ETL Attrition Data',
    schedule=timedelta(days=1),
    start_date=datetime(2022, 11, 6),
    catchup=False,
    tags=['example'],
) as dag:

    ExtractData = PythonOperator(
        task_id='Extract_Data',
        python_callable=AttritionClass.ExtractData,
        retries=1,
        )

    TransformData = PythonOperator(
        task_id='Transform_Data',
        python_callable=AttritionClass.TransformData,
        retries=2,
    )
    

    LoadData_psql = PythonOperator(
        task_id='Load_Data_PostgreSQL',
        python_callable=AttritionClass.LoadData_postgreSQL,
        retries=3,
    )


    SelesaiData = BashOperator(
        task_id='Selesai',
        depends_on_past=False,
        bash_command="sleep 5",
        retries=5,
    )
    ExtractData >> TransformData >> LoadData_psql >> SelesaiData